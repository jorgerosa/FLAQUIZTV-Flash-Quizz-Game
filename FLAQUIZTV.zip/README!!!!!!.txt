************************************************************************************
LICENCE:
************************************************************************************

FlaQuizTV - All copyrights are reserved to Jorge Rosa - email: jorge.bigarte@gmail.com
Portfolio: http://sites.google.com/site/jorgerosaportfolio
Download game, link #2: http://sourceforge.net/projects/flaquiztv
Please, send feedback or comment. Thankyou!

Pictures were taken from internet, their copyrights belong to their owners/authors.

************************************************************************************





************************************************************************************
INSTALL:
************************************************************************************

1) Extract zip file, and run "game.exe"... That�s all!

2) OR run "game.swf" ("game.swf" could be opened with your internet browser).

************************************************************************************





************************************************************************************
CHANGE TO OTHER AVAILABLE IDIOM AND/OR QUESTIONS: 
************************************************************************************

1) Check for current available idioms in "idioms" folder.

2) Check for current available questions in "questions" folder.

3) Edit "settings.txt" and Save. (restart game) <-- Recommended: Create a backup of this file first!

************************************************************************************





************************************************************************
CREATE YOUR OWN IDIOM AND/OR QUESTIONS: 
************************************************************************

1) Create a new "myidiom.txt" (in "idioms" folder).

2) Create a new "myquestions_theme.xml" (in "questions" folder).

3) Edit "settings.txt" and Save. (restart game) <-- Recommended: Create a backup of this file first!

Note: Don�t forget to add images, in XML and in "images" folder, if you want better results. ;)
Images must have: 765px width X 254px height

************************************************************************





************************************************************************
TIPS: 
************************************************************************

1) Have things ordered! Adding a prefix to images (same as XML file) is a good way to go.
Example: if your xml�s file name is: "english_history.xml", add your images, such as "english_history_london.jpg" and "english_history_liverpool.jpg"...

2) Animated backgrounds: add "swf" files instead of "jpg" files in "images" folder, and edit accordingly it, in XML file.

3) To edit XML and idiom.txt data, we recomend you to use "Notepad++", you can download it here: http://notepad-plus.sourceforge.net

4) Create your own XML/idiom/images data, and send all to my email: jorge.bigarte@gmail.com, so we can also share it! Thankyou! :)

************************************************************************


